# How to Run

Using Zack Wilson's Flink Environment in this repo, trigger the ip_session job using the following make command:

```sh
    make ip_session_job
```